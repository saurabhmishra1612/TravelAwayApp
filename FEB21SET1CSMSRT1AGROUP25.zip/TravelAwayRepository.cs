﻿using Infosys.TravelAway.DAL.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Infosys.TravelAway.DAL
{
    public class TravelAwayRepository
    {
        private TravelAwayDBContext Context { get; set; }
        public TravelAwayRepository()
        {
            Context = new TravelAwayDBContext();
        }

public int RegisterNewCustomer(Customer newCust)
        {
            int result;
            try
            {
                SqlParameter prmFirstName = new SqlParameter("@firstName", newCust.FirstName);
                SqlParameter prmLastName = new SqlParameter("@lastName", newCust.LastName);
                SqlParameter prmPassword = new SqlParameter("@userPassword", newCust.UserPassword);
                SqlParameter prmGender = new SqlParameter("@gender", newCust.Gender);
                SqlParameter prmEmailId = new SqlParameter("@emailId", newCust.EmailId);
                SqlParameter prmDob = new SqlParameter("@dateOfBirth", newCust.DateOfBirth);
                SqlParameter prmNumber = new SqlParameter("@contactNumber", newCust.ContactNumber);
                SqlParameter prmAddress = new SqlParameter("@address", newCust.Address);
                
             SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
                prmReturnResult.Direction = System.Data.ParameterDirection.Output;
                result = Context.Database.ExecuteSqlRaw("EXEC @ReturnResult= usp_RegisterCustomer @emailId,@firstName,@lastName,@userPassword, " +
                    "@gender,@contactNumber,@dateOfBirth,@address",
                    prmReturnResult, prmEmailId, prmFirstName, prmLastName, prmPassword, prmGender, prmNumber, prmDob, prmAddress);
                if (result > 0)
                {
                    return result;
                }
               
 else
                {
                    result = -98;
                    return result;
                }
            }
            catch (Exception e)
            {
                result = -99;
                return result;
            }

        }

// Method to validate a User
        public int ValidateLoginCustomer(string emailId, string password)
        {
            int roleId = 0;
            try
            {
                var objUser = (from usr in Context.Customer
                               where usr.EmailId == emailId && usr.UserPassword == password
                               select usr.Role).FirstOrDefault<Roles>();
                if (objUser != null)
                {
                    roleId = objUser.RoleId;
                }
                else
                {
                    roleId = 0;
                }
            }
            catch (Exception)
            {
                roleId = -99;
            }
            return roleId;
        }

public bool EditProfile(Customer cust)
        {
            bool status = false;
            Customer cust1 = Context.Customer.Find(cust.EmailId);
            try
            {
                if (cust1 != null)
                {
                    cust1.FirstName = cust.FirstName;
                    cust1.LastName = cust.LastName;
                    cust1.ContactNumber = cust.ContactNumber;
                    cust1.Address = cust.Address;
                    cust1.Gender = cust.Gender;
                    cust1.DateOfBirth = cust.DateOfBirth;
                    Context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception e)
            {
                status = false;
                Console.WriteLine(e.Message);
            }
            return status;
        }

 public List<Package> GetPackages()
        {
            List<Package> package;
            try
            {
                package = Context.Package.FromSqlRaw("SELECT * FROM dbo.ufn_ViewAllPackages()").ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                package = null;
            }
            return package;
        }
        public Customer GetCustomerById(string email)
        {
            Customer cust;
            try
            {

                cust = (from usr in Context.Customer
                        where usr.EmailId == email
                        select usr).FirstOrDefault();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                cust = null;
            }
            return cust;
        }

public List<PackageCategory> GetPackageCategories()
        {
            {
                List<PackageCategory> obj = null;
                try
                {
                    obj = (from a in Context.PackageCategory select a).ToList();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    obj = null;
                }
                return obj;
            }
        }
        // Method should return List<Package>
        public List<Package> GetPackageByCategoryId(int categoryId)
        {
            List<Package> obj = null;
            try
            {
                obj = (from a in Context.Package where a.PackageCategoryId == categoryId select a).ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                obj = null;
            }
            return obj;
        }

 public List<PackageDetails> GetPackageDetailsByPackageId(int packageId)
        {
            List<PackageDetails> obj = null;
            try
            {
                obj = (from a in Context.PackageDetails where a.PackageId == packageId select a).ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                obj = null;
            }
            return obj;
        }

        public int EmployeeLogin(string emailId, string password)
        {
            int roleId = 0;
            try
            {
                var objUser = (from usr in Context.Employee
                               where usr.EmailId == emailId && usr.Password == password
                               select usr.Role).FirstOrDefault<Roles>();
                if (objUser != null)
                {
                    roleId = objUser.RoleId;
                }
                else
                {
                    roleId = 0;
                }
            }
            catch (Exception)
            {
                roleId = -99;
            }
            return roleId;
        }
    }
}


//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using Infosys.TravelAway.DAL.Models;
//using Microsoft.Data.SqlClient;
//using Microsoft.EntityFrameworkCore;

//namespace Infosys.TravelAway.DAL
//{
//    public class TravelAwayRepository
//    {
//        TravelAwayDBContext context;

//        public TravelAwayRepository()
//        {
//            context = new TravelAwayDBContext();
//        }

//        //public bool AddCustomer(params Customer[] custDetails)
//        //{
//        //    bool status = false;
//        //    try
//        //    {
//        //        //context.Customer.Add(customer);
//        //        context.Customer.AddRange(custDetails);
//        //        context.SaveChanges();
//        //        status = true;
//        //    }
//        //    catch (Exception)
//        //    {
//        //        status = false;
//        //    }
//        //    return status;
//        //}


//        //public string CustLogin(string emailId, string password)
//        //{
//        //    string roleName = "";
//        //    try
//        //    {
//        //        var objUser = (from usr in context.Customer
//        //                       where usr.EmailId == emailId && usr.UserPassword == password
//        //                       select usr.Role).FirstOrDefault<Roles>();
//        //        if (objUser != null)
//        //        {
//        //            roleName = objUser.RoleName;
//        //        }
//        //        else
//        //        {
//        //            roleName = "Invalid credentials";
//        //        }
//        //    }
//        //    catch (Exception)
//        //    {
//        //        roleName = "Invalid credentials";
//        //    }
//        //    return roleName;
//        //}
//        //public string EmpLogin(string emailId, string password)
//        //{
//        //    string roleName = "";
//        //    try
//        //    {
//        //        var objUser = (from usr in context.Customer
//        //                       where usr.EmailId == emailId && usr.UserPassword == password
//        //                       select usr.Role).FirstOrDefault<Roles>();
//        //        if (objUser != null)
//        //        {
//        //            roleName = objUser.RoleName;
//        //        }
//        //        else
//        //        {
//        //            roleName = "Invalid credentials";
//        //        }
//        //    }
//        //    catch (Exception)
//        //    {
//        //        roleName = "Invalid credentials";
//        //    }
//        //    return roleName;
//        //}

//        //public List<PackageCategory> GetAllPackages()
//        //{
//        //    var categoriesList = (from category in context.PackageCategory
//        //                          orderby category.PackageCategoryId
//        //                          select category).ToList();
//        //    return categoriesList;
//        //}

//        public bool AddCustomer(Customer customer)
//        {
//            bool status = false;
//            Customer localUser = new Customer();
//            Customer temp = new Customer();
//            try
//            {
//                temp = context.Customer.Where(P => P.EmailId == customer.EmailId).Select(p => p).FirstOrDefault();
//                if(temp==null)
//                {
//                    localUser.FirstName = customer.FirstName;
//                    localUser.LastName = customer.LastName;
//                    localUser.EmailId = customer.EmailId;
//                    localUser.UserPassword = customer.UserPassword;
//                    localUser.Gender = customer.Gender;
//                    localUser.ContactNumber = customer.ContactNumber;
//                    localUser.DateOfBirth = customer.DateOfBirth;
//                    localUser.Address = customer.Address;
//                    context.Add<Customer>(localUser);
//                    context.SaveChanges();
//                    status = true;
//                }
//                else
//                {
//                    status = false;
//                }
//                //context.Customer.Add(customer);

//            }
//            catch (Exception)
//            {
//                status = false;
//            }
//            return status;
//        }
//        public bool CustLogin(string emailId, string password)
//        {
//            bool status = false;
//            try
//            {
//                var objUser = (from usr in context.Customer
//                               where usr.EmailId == emailId && usr.UserPassword == password
//                               select usr).FirstOrDefault();
//                if (objUser != null)
//                {
//                    status = true;
//                }
//                else
//                {
//                    status = false;
//                }
//            }
//            catch (Exception)
//            {
//                status = false;
//            }
//            Console.WriteLine(status);
//            return status;
//        }
//        public bool EditProfile(string emailId,string firstname,string lastname,decimal contactnumber,string gender,string address)
//        {
//            bool status = false;
//            var record = context.Customer.Find(emailId);
//            try
//            {
//                if (record != null)
//                {
//                    record.FirstName = firstname;
//                    record.LastName = lastname;
//                    record.ContactNumber = contactnumber;
//                    record.Address = address;

//                    context.SaveChanges();
//                    status = true;
//                }
//            }
//            catch (Exception)
//            {
//                status = false;
//            }
//            return status;
//        }
//    }
//}
