import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserServices } from '../travelAway-services/user-services/user.service';


@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateprofileComponent implements OnInit {
  editform: FormGroup;

  msg: string;
  status: boolean;
  errorMsg: string;
  errMsg: string;
  showDiv: boolean;
  email: string = "saurabh@gmail.com";

  genders: any = ['M', 'F'];

  constructor(private formBuilder: FormBuilder, private _userService: UserService) { }

  ngOnInit(): void {

    this.editform = this.formBuilder.group({
      gender: ['', [Validators.required]],
      firstName: ['', [Validators.required, Validators.pattern('^[a-zA-Z]*$')]],
      lastName: ['', [Validators.required, Validators.pattern('^[a-zA-Z]*$')]],
      emailId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(9), Validators.maxLength(15)]],
      confirmPassword: ['', Validators.required],
      dob: ['', checkDate()],
      contactNumber: ['', [Validators.required, Validators.pattern('^[1-9][0-9]{9}*$')]],
      address: ['', [Validators.required]]
    });
  }

  editCustomer(form: formGroup) {
    this._userService.editCustomer(this.editform.value.firstName, this.editform.value.lastName, this.editform.value.gender,
    this.editform.value.dob, this.editform.value.contactNumber, this.editform.value.address, this.email).subscribe(
      x => {
        if (x == true) {
          this.status = true;
          this.showDiv = true;
          this.msg = "updated successfully";
        }
        else {
          alert("something  went wrong")
        }
      },
      responseLoginError => {
        console.log(responseLoginError)
      },
      () => { console.log("edit user method executed successfully") }
    );
  }

}

export function checkDate() {
  return (
    control: FormControl
  ): { [key: string]: boolean } | null => {
    const givenDate = new Date(control.value);
    const currentDate = new Date();

    if (givenDate <= currentDate || givenDate == null) {
      return null
    }
    else {
      return {
        dateError: true
      }
    }
  }
}
