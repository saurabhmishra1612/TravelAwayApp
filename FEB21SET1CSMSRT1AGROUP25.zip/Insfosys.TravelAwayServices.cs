// name change kr lena

[HttpPost]
public JsonResult AddCustomer(Customer customer)
{
    bool status = false;
    string message;
    try
    {
        status = repository.RegisterUser(customer);
        if (status)
        {
            message = "Successfully validete operation";
        }
        else
        {
            message = "Unsucessfully valideted operation!";
        }
    }
    catch (Exception)
    {
        message = "Some error occured,please try again!";
    }
    return Json(message);
}

[HttpPost]
public JsonResult ValidateCustomer(Customer customer)
{
	bool status = false;
	string msg;
    try
    {
        status = repository.ValidateCustomer(customer.EmailId, customer.Password);
        if (status)
        {
            msg = "Successfully validete operation";
        }
        else
        {
            msg = "Unsucessfully valideted operation";
        }
    }
    catch (Exception)
    {
        msg = "Some error occured,please try again!";
    }
    return Json(msg);
}

[HttpPut]
public JsonResult EditProfile(Customer c)
{
    bool status = false;
    string msg;
    Infosys.TravelAwayDAL.Models.Customer cust = new Infosys.TravelAwayDAL.Models.Customer();
    try
    {
        if (ModelState.IsValid)
        {
            cust.EmailId = c.EmailId;
            cust.FirstName = c.FirstName;
            cust.LastName = c.LastName;
            cust.ContactNumber = c.ContactNumber;
            cust.Address = c.Address;
            cust.Gender = c.Gender;

            status = repository.EditProfile(cust.EmailId, cust.FirstName, cust.LastName, cust.ContactNumber, cust.Gender, cust.Address);
        }
        if (status)
        {
            msg = "Successfull edit profile operation";
        }
        else
        {
            msg = "Unsucessful edit profile operation";
        }
    }
    catch (Exception)
    {
        status = false;
        msg = "Some error occured, try again later";
    }
    return Json(msg);
}