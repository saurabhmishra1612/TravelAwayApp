﻿using System;
using Infosys.TravelAway;
using System.Linq;
using Infosys.TravelAway.DAL;

namespace Infosys.TravelAway.ConsoleUI
{
    class Program
    {
        public static void Main(string[] args)
        {
            TravelAwayRepository repository = new TravelAwayRepository();
            bool result = repository.AddAccomodationDetails(1,4001,"alpha","hyd",3,4,10000,"luxe");
            if (result)
            {
                Console.WriteLine("New category added successfully");
            }
            else
            {
                Console.WriteLine("Something went wrong. Try again!");
            }
        }
    }
}
