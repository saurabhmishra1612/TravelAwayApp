import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-packages',
  templateUrl: './view-packages.component.html',
  styleUrls: ['./view-packages.component.css']
})
export class ViewPackagesComponent implements OnInit {

  packages: any[];
  showMsgDiv: boolean = false;
  constructor() { }
  ngOnInit() {

    this.packages = [
      { "packagesId": 1, "packageName": "Andaman and Nicobar", "packageCategoryName": "Adventure" },
      { "packagesId": 2, "packageName": "America", "packageCategoryId": 1, "packageCategoryName": "Adventure" },

    ]
    if (this.packages == null) {
      this.showMsgDiv = true;
    }
  }
}
