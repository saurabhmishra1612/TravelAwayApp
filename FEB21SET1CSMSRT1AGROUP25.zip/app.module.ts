import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UpdateprofileComponent } from './updateprofile/updateprofile.component';
import { ViewpackagedetailsComponent } from './viewpackagedetails/viewpackagedetails.component';
import { HomeComponent } from './home/home.component';
import { routing } from './app.routing';
import { CommonLayoutComponent } from './layout/common-layout/common-layout.component';
import { ViewPackagesComponent } from './view-packages/view-packages.component';
import { LogoutComponent } from './logout/logout.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    UpdateprofileComponent,
    ViewpackagedetailsComponent,
    HomeComponent,
    CommonLayoutComponent,
    ViewPackagesComponent,
    LogoutComponent,
    HttpClientModule
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
