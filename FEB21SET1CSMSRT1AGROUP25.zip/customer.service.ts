import { Injectable } from '@angular/core';
import { ICustomer } from 'src/app/TravelAway-interfaces/Customer';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  //customer: ICustomer[];

  //constructor(private http: HttpClient) { }
  //  ValidateCustomer(id: string, password: string): Observable < string >
  //  {
  //   var userObj: ICustomer
  //    userObj = { EmailId: id, UserPassword: password, Gender: null, RoleId: null, DateOfBirth: null, Address: null, FirstName: null, LastName: null, ContactNumber: null };
  //    return this.http.post<string>('https://localhost:44347/api/Customer/ValidateCustomer', userObj).pipe(catchError(this.errorHandler));
  //  }

  //  InsertUserDetails([): Observable<JSON> {
  //    var custObj: ICustomer
  //    custObj = { +fbirth, ContactNumber: contactnumber, Address: address };
  //    let temp = this.http.post<JSON>('https://localhost:44347/api/Customer/InsertUserDetails', custObj).pipe(catchError(this.errorHandler));
  //    return temp;
  //  }

  //  errorHandler(error: HttpErrorResponse) {
  //    console.error(error);
  //    return throwError(error.message || "Server Error");
  //  }
  //}

  constructor(private http: HttpClient) { }
  validateCredentials(email: string, password: string, loginRole: number): Observable<number> {
    let temp;
    if (loginRole == 1) {
      var custObj: ICustomer;
      //custObj = { EmailId: email, UserPassword: password, FirstName: null, LastName: null, RoleId: null, Gender: null, DateOfBirth: null, Address: null, ContactNumber: null };
      temp = this.http.post<number>('https://localhost:44347/api/Customer/ValidateLoginCustomer', { EmailId: email, UserPassword: password }).pipe(catchError(this.errorHandler));
    }
    //else if(loginRole == 2){
    //  var EmpObj = IEmployee;
    //  EmpObj = { EmailId: email, UserPassword: password, FirstName: null, LastName: null, RoleId: null };
    //  temp = this.http.post<number>('https://localhost:44347/api/Customer/', EmpObj).pipe(catchError(this.errorHandler));
    //}
    return temp;
  }

  addUserDetails(firstname: string, lastname: string, emailid: string, password: string, contactnumber: number, address: string, gender: string, dateofbirth: Date, roleId: number): Observable<JSON> {
    var custObj: ICustomer
    custObj = {
      EmailId: emailid, UserPassword: password, FirstName: firstname, LastName: lastname, RoleId: roleId,
      Gender: gender, DateOfBirth: dateofbirth, Address: address, ContactNumber: contactnumber
    };
    let temp = this.http.post<JSON>('https://localhost:44347/api/Customer/', custObj).pipe(catchError(this.errorHandler));
    return temp;
  }
}




