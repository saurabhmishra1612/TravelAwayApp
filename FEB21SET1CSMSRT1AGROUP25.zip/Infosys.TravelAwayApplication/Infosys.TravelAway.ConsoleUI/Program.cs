﻿using System;
using Infosys.TravelAway.DAL;
using Infosys.TravelAway.DAL.Models;

namespace Infosys.TravelAway.ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            TravelAwayRepository repository = new TravelAwayRepository();
            Customer CustOne = new Customer();
            CustOne.EmailId = "Saipitani000@gmail.com";
            //CustOne.RoleId = 2;
            CustOne.FirstName = "Sai000";
            CustOne.LastName = "Pitani";
            CustOne.UserPassword = "Sai@12345";
            CustOne.Gender = "F";
            CustOne.ContactNumber = 9424322131;
            CustOne.DateOfBirth = DateTime.FromOADate(01 / 01 / 1998);
            CustOne.Address = "Jaipur";

            int result = repository.AddCustomer(CustOne);
            //int result = repository.ValidateLoginCustomer("jain.sakshi@gmail.com", "SAKSHI@1234");
            //bool result = repository.EditProfile("Art@gmail.com", "ssaai", "ppp",7894561232,"F", "srtejdd");
            if (result==1)
            {
                Console.WriteLine("Customer Details details added successfully!");
            }
            else
            {
                Console.WriteLine("Some error occurred. Try again!!");
            }
            //var categories = repository.GetPackageCategories();
            //foreach (var category in categories)
            //{
            //    Console.WriteLine("{0}\t\t{1}", category.PackageCategoryId, category.PackageCategoryName);
            //}
        }

    }
}
