﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Infosys.TravelAway.DAL.Models;
using Infosys.TravelAway.DAL;

namespace Infosys.TravelAway.Services.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CustomerController : Controller
    {
        TravelAwayRepository tra;
        public CustomerController()
        {
            tra = new TravelAwayRepository();
        }

        //        //[HttpPost]
        //        //public JsonResult InsertUserDetails(Customer customer)
        //        //{
        //        //    var status = false;
        //        //    try
        //        //    {
        //        //        status = tra.AddCustomer(customer);
        //        //    }
        //        //    catch (Exception)
        //        //    {
        //        //        status = false;
        //        //    }
        //        //    return Json(status);
        //        //}
        //        [HttpPost]
        //        public JsonResult InsertUserDetails(Customer customer)
        //        {
        //            bool status = false;
        //            string message;
        //            try
        //            {
        //                status = tra.AddCustomer(customer);
        //                if (status)
        //                {
        //                    message = "Successfully validated operation";
        //                }
        //                else
        //                {
        //                    message = "Unsucessfully validated operation!";
        //                }
        //            }
        //            catch (Exception)
        //            {
        //                message = "Some error occured,please try again!";
        //            }
        //            return Json(message);
        //        }

        [HttpPost]
        public int ValidateLoginCustomer(Customer customer)
        {
            int role;
            string emailId = customer.EmailId;
            string password = customer.UserPassword;
            try
            {
                role = tra.ValidateLoginCustomer(emailId, password);
            }
            catch (Exception)
            {
                role = -99;
            }
            return role;
        }
        [HttpGet]
        public JsonResult GetPackages()
        {
            List<Package> packageList;
            try
            {
                packageList = tra.GetPackages();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                packageList = null;
            }
            return Json(packageList);
        }


        //[HttpGet]  get costumers
        //public JsonResult GetCustomerDetails(string emailId)
        //{
        //    Customer customer;
        //    try
        //    {
        //        customer = tra.GetCustomerDetails(emailId);
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e.Message);
        //        customer = null;
        //    }
        //    return Json(customer);
        //}


        // API to get a list of all package categories
        [HttpGet]
        public JsonResult GetPackageCategories()
        {
            List<PackageCategory> packageCategoriesList;
            try
            {
                packageCategoriesList = tra.GetPackageCategories();
            }
            catch (Exception)
            {
                packageCategoriesList = null;
            }
            return Json(packageCategoriesList);
        }

        // API to get a list of package filtered by categoryId
        //[HttpGet]
        //public JsonResult GetPackagesByCategoryId(int categoryId)
        //{
        //    List<Package> packageList;
        //    try
        //    {
        //        packageList = tra.GetPackagesByCategoryId(categoryId);
        //    }
        //    catch (Exception)
        //    {
        //        packageList = null;
        //    }
        //    return Json(packageList);
        //}

        [HttpGet]
        public JsonResult GetPackageDetailsByPackageId(string packageId)
        {
            List<PackageDetails> packageDetails;
            try
            {
                int Id = Convert.ToInt32(packageId);
                packageDetails = tra.GetPackageDetailsByPackageId(Id);
            }
            catch (Exception)
            {
                packageDetails = null;
            }
            return Json(packageDetails);
        }


        #region - CREATE
        // API to register a user
        // Return 1 indicates success
        //       -98 indicates invalid details
        //       -99 indicates an exception
        [HttpPost]
        public int AddCustomer(Customer custObj)
        {
            int role;
            try
            {
                role = tra.AddCustomer(custObj);
            }
            catch (Exception)
            {
                role = -99;
            }
            return role;
        }
        #endregion
 #region - UPDATE
        //[HttpPut]
        //// API to update user details
        //public bool UpdateProfile(Customer custObj)
        //{
        //    bool status;
        //    try
        //    {
        //        status = tra.UpdateProfile(custObj);
        //    }
        //    catch (Exception)
        //    {
        //        status = false;
        //    }
        //    return status;
        //}
        #endregion

        #region - DELETE
        #endregion
    }
}


    

//        [HttpPut]
//        public JsonResult EditProfile(Customer c)
//        {
//            bool status = false;
//            string msg;
//            Infosys.TravelAway.DAL.Models.Customer cust = new Infosys.TravelAway.DAL.Models.Customer();
//            try
//            {
//                if (ModelState.IsValid)
//                {
//                    cust.EmailId = c.EmailId;
//                    cust.FirstName = c.FirstName;
//                    cust.LastName = c.LastName;
//                    cust.ContactNumber = c.ContactNumber;
//                    cust.Address = c.Address;
//                    cust.Gender = c.Gender;

//                    status = tra.EditProfile(cust.EmailId, cust.FirstName, cust.LastName, cust.ContactNumber, cust.Gender, cust.Address);
//                }
//                if (status)
//                {
//                    msg = "Successfull edit profile operation";
//                }
//                else
//                {
//                    msg = "Unsucessful edit profile operation";
//                }
//            }
//            catch (Exception)
//            {
//                status = false;
//                msg = "Some error occured, try again later";
//            }
//            return Json(msg);
//        }
//    }
//}
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Infosys.TravelAway.DAL;
//using Infosys.TravelAway.DAL.Models;

//namespace Infosys.TravelAway.Services.Controllers
//{
//    [Route("api/[controller]/[action]")]
//    [ApiController]
//    public class TravelAwayController : Controller
//    {
//        TravelAwayRepository Tra;
//        public TravelAwayController()
//        {
//            Tra = new TravelAwayRepository();
//        }
//        #region - READ
//        // API to validate a user
//        // Returns user role
//        //         1 represents Customer
//        //         2 represents Employee
//        //         0 represents Invalid
//        //        -99 represents Exception
//        [HttpPost]
//        public int ValidateLoginCustomer(Customer cust)
//        {
//            int role;
//            string emailId = cust.EmailId;
//            string password = cust.UserPassword;
//            try
//            {
//                role = Tra.ValidateLoginCustomer(emailId, password);
//            }
//            catch (Exception)
//            {
//                role = -99;
//            }
//            return role;
//        }
//    }
//}