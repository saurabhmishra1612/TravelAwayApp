import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-packages',
  templateUrl: './view-packages.component.html',
  styleUrls: ['./view-packages.component.css']
})
export class ViewPackagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
