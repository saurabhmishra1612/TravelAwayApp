export interface ICustomer {
        EmailId: string
        RoleId:number
        FirstName :string
        LastName :string
        UserPassword :string
        Gender:string 
        ContactNumber:number
        DateOfBirth :Date
        Address :string
}
