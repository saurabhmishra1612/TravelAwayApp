import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewpackagedetailsComponent } from './viewpackagedetails.component';

describe('ViewpackagedetailsComponent', () => {
  let component: ViewpackagedetailsComponent;
  let fixture: ComponentFixture<ViewpackagedetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewpackagedetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewpackagedetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
