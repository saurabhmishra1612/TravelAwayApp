import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-package',
  templateUrl: './book-package.component.html',
  styleUrls: ['./book-package.component.css']
})
export class BookPackageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
