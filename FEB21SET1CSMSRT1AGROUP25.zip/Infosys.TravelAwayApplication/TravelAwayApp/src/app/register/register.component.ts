//import { Component, OnInit } from '@angular/core';
//import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
//import { NgForm } from '@angular/forms';
//import { Router } from '@angular/router';
//import { CustomerService } from '../TravelAwayservices/Customer-Service/customer.service';
////import { Session } from 'inspector';

//@Component({
//  selector: 'app-register',
//  templateUrl: './register.component.html',
//  styleUrls: ['./register.component.css']
//})
//export class RegisterComponent implements OnInit {
//  registerForm: FormGroup;
//  msg: string;
//  showDiv: boolean;
//  errorMsg: string;
//  status: string;
//  constructor(private customerservice: CustomerService, private formBuilder: FormBuilder) {
//    this.registerForm = this.formBuilder.group({
//      firstname: ['', [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
//      lastname: ['', [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
//      emailid: ['', [Validators.required, Validators.minLength(12)]],
//      userpassword: ['', [Validators.required, Validators.minLength(8)]],
//      confirmpassword: [''],
//      gender: ['', Validators.required],
//      dateofbirth: ['', Validators.required],
//      contactnumber: ['', Validators.required],
//      address: ['', Validators.required]
//    });
//  }
//  ngOnInit(): void {
//  }
//  submitRegisterForm(form: FormGroup) {
//    this.customerservice.addUserDetails(this.registerForm.value.emailid, this.registerForm.value.firstname, this.registerForm.value.lastname, this.registerForm.value.userpassword,
//      this.registerForm.value.contactnumber, this.registerForm.value.dateofbirth, this.registerForm.value.address, this.registerForm.value.gender).subscribe(
//        responseRegisterStatus => {
//          this.status = responseRegisterStatus;
//          this.showDiv = true;
//          if (this.status == "1") {
//            this.msg = "Register Successful";
//            sessionStorage.setItem('userName', form.value.email);
//          }
//          else {
//            this.msg="Try again with valid credentials"
//          }
//        },
//        () => console.log("SubmitLoginForm method executed successfully")
//      );
//    }

//  }

//  //  comparePasswords(fb: FormGroup){
//  //    let confirmPswrdctrl = fb.get('ConfirmPassword');
//  //    if (confirmPswrdctrl.errors == null || 'passwordMismatch' in confirmPswrdctrl.errors) {
//  //      if (fb.get('Password').value != confirmPswrdctrl.value)
//  //        confirmPswrdctrl.setErrors({ passwordMismatch: true });
//  //      else
//  //        confirmPswrdctrl.setErrors(null);
//  //    }
//  //  }
//  //}
//break
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from '../TravelAwayservices/Customer-Service/customer.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  msg: string;
  showDiv: boolean;
  errorMsg: string;
  status: number;
  constructor(private customerservice: CustomerService, private formBuilder: FormBuilder) {
    this.registerForm = this.formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
      lastname: ['', [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
      emailid: ['', [Validators.required, Validators.minLength(12)]],
      userpassword: ['', [Validators.required, Validators.minLength(8)]],
      confirmpassword: [''],
      gender: ['', Validators.required],
      dateofbirth: ['', Validators.required],
      contactnumber: ['', Validators.required],
      address: ['', Validators.required]
    });
  }


  ngOnInit(): void {
  }
  SubmitForm(form: NgForm) {
    var email = form.value.emailid;
    this.customerservice.addUserDetails(form.value.firstname, form.value.lastname, form.value.emailid,
      form.value.userpassword, parseInt(form.value.contactnumber), form.value.address, form.value.gender, new Date("1999-08-23"), 1).subscribe(
        responseRegisterStatus => {
          this.status = responseRegisterStatus;
          this.showDiv = true;
          if (this.status == 1) {
            this.msg = "Registered Successfully";
            sessionStorage.setItem('userName', email);
            sessionStorage.setItem('userRole', "Customer");
            //this.router.navigate(['/home']);
          } else {
            this.msg = "Not able to register";
          }
        },
        responseRegisterError => {
          this.errorMsg = responseRegisterError;
        },
        () => console.log("SubmitForm method executed successfully")
      );
  }
}


