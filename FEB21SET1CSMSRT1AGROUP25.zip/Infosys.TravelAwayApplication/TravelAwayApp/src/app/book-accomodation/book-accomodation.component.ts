import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-accomodation',
  templateUrl: './book-accomodation.component.html',
  styleUrls: ['./book-accomodation.component.css']
})
export class BookAccomodationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
