﻿using Infosys.TravelAway.DAL.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Infosys.TravelAway.DAL
{
    public class TravelAwayRepository
    {
        private TravelAwayDBContext Context { get; set; }
        public TravelAwayRepository()
        {
            Context = new TravelAwayDBContext();
        }

        #region Add Customer
        public int AddCustomer(Customer customer)
        {
            int status = 0;
            Customer localUser = new Customer();
            Customer temp = new Customer();
            try
            {
                temp = Context.Customer.Where(P => P.EmailId == customer.EmailId).Select(p => p).FirstOrDefault();
                if (temp == null)
                {
                    localUser.FirstName = customer.FirstName;
                    localUser.LastName = customer.LastName;
                    localUser.EmailId = customer.EmailId;
                    localUser.UserPassword = customer.UserPassword;
                    localUser.Gender = customer.Gender;
                    localUser.ContactNumber = customer.ContactNumber;
                    localUser.DateOfBirth = customer.DateOfBirth;
                    localUser.Address = customer.Address;
                    Context.Add<Customer>(localUser);
                    Context.SaveChanges();
                    status = 1;
                }
                else
                {
                    status = 0;
                }
                //context.Customer.Add(customer);

            }
            catch (Exception)
            {
                status = 0;
            }
            return status;
        }
        #endregion

        #region Login
        public int ValidateLoginCustomer(string emailId, string password)
        {
            int roleId = 0;
            try
            {
                var objUser = (from usr in Context.Customer
                               where usr.EmailId == emailId && usr.UserPassword == password
                               select usr.Role).FirstOrDefault<Roles>();
                if (objUser != null)
                {
                    roleId = objUser.RoleId;
                }
                else
                {
                    roleId = 0;
                }
            }
            catch (Exception)
            {
                roleId = -99;
            }
            return roleId;
        }
        #endregion

        #region Edit Profile
        public bool EditProfile(Customer cust)
        {
            bool status = false;
            Customer cust1 = Context.Customer.Find(cust.EmailId);
            try
            {
                if (cust1 != null)
                {
                    cust1.FirstName = cust.FirstName;
                    cust1.LastName = cust.LastName;
                    cust1.ContactNumber = cust.ContactNumber;
                    cust1.Address = cust.Address;
                    cust1.Gender = cust.Gender;
                    cust1.DateOfBirth = cust.DateOfBirth;
                    Context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception e)
            {
                status = false;
                Console.WriteLine(e.Message);
            }
            return status;
        }
        #endregion

        #region Get Packages
        public List<Package> GetPackages()
        {
            List<Package> package;
            try
            {
                package = Context.Package.FromSqlRaw("SELECT * FROM dbo.ufn_ViewAllPackages()").ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                package = null;
            }
            return package;
        }
        #endregion

        #region Get Customer by Id
        public Customer GetCustomerById(string email)
        {
            Customer cust;
            try
            {

                cust = (from usr in Context.Customer
                        where usr.EmailId == email
                        select usr).FirstOrDefault();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                cust = null;
            }
            return cust;
        }
        #endregion

        #region Get Package categories
        public List<PackageCategory> GetPackageCategories()
        {
            {
                List<PackageCategory> obj = null;
                try
                {
                    obj = (from a in Context.PackageCategory select a).ToList();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    obj = null;
                }
                return obj;
            }
        }
        #endregion

        #region Get Packages by Category Id
        public List<Package> GetPackagesByCategoryId(int categoryId)
        {
            List<Package> obj = null;
            try
            {
                obj = (from a in Context.Package where a.PackageCategoryId == categoryId select a).ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                obj = null;
            }
            return obj;
        }
        #endregion

        #region Get Package Details By Package Id
        public List<PackageDetails> GetPackageDetailsByPackageId(int packageId)
        {
            List<PackageDetails> obj = null;
            try
            {
                obj = (from a in Context.PackageDetails where a.PackageId == packageId select a).ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                obj = null;
            }
            return obj;
        }
        #endregion

        #region Add Hotel
        public int AddHotel(Hotel hotel)
        {
            int status = 0;
            Hotel localUser = new Hotel();
            Hotel temp = new Hotel();
            try
            {
                temp = Context.Hotel.Where(P => P.HotelName == hotel.HotelName).Select(p => p).FirstOrDefault();
                if (temp == null)
                {
                    localUser.HotelId = hotel.HotelId;
                    localUser.HotelName = hotel.HotelName;
                    localUser.HotelRating = hotel.HotelRating;
                    localUser.SingleRoomPrice = hotel.SingleRoomPrice;
                    localUser.SuiteRoomPrice = hotel.SuiteRoomPrice;
                    localUser.DoubleRoomPrice = hotel.DoubleRoomPrice;
                    localUser.DeluxeeRoomPrice = hotel.DeluxeeRoomPrice;
                    localUser.City = hotel.City;
                    localUser.PackageId = hotel.PackageId;
                    Context.Add<Hotel>(localUser);
                    Context.SaveChanges();
                    status = 1;
                }
                else
                {
                    status = 0;
                }
            }
            catch (Exception)
            {
                status = 0;
            }
            return status;
        }
        #endregion

        #region Add Vehicle
        public int AddVehicle(Vehicle vehicle)
        {
            int status = 0;
            Vehicle localUser = new Vehicle();
            //Hotel temp = new Hotel();
            try
            {
                localUser.VehicleId = vehicle.VehicleId;
                localUser.VehicleName = vehicle.VehicleName;
                localUser.VehicleType = vehicle.VehicleType;
                localUser.RatePerHour = vehicle.RatePerHour;
                localUser.RatePerKm = vehicle.RatePerKm;
                localUser.BasePrice = vehicle.BasePrice;
                Context.Add<Vehicle>(localUser);
                Context.SaveChanges();
                status = 1;
            }
            catch (Exception)
            {
                status = 0;
            }
            return status;
        }
        #endregion

        #region Emloyee Login
        public int EmployeeLogin(string emailId, string password)
        {
            int roleId = 0;
            try
            {
                var objUser = (from usr in Context.Employee
                               where usr.EmailId == emailId && usr.Password == password
                               select usr.Role).FirstOrDefault<Roles>();
                if (objUser != null)
                {
                    roleId = objUser.RoleId;
                }
                else
                {
                    roleId = 0;
                }
            }
            catch (Exception)
            {
                roleId = -99;
            }
            return roleId;
        }
        #endregion

        #region Book Package
        public int BookPackage(BookPackage bookpackage)
        {
            int status = 0;
            BookPackage localUser = new BookPackage();
            BookPackage temp = new BookPackage();
            Customer cust1 = Context.Customer.Find(bookpackage.EmailId);
            try
            {
                if (cust1 != null)
                {
                    localUser.ContactNumber = bookpackage.ContactNumber;
                    localUser.Address = bookpackage.Address;
                    localUser.DateOfTravel = bookpackage.DateOfTravel;
                    localUser.NumberOfAdults = bookpackage.NumberOfAdults;
                    localUser.NumberOfChildren = bookpackage.NumberOfChildren;
                    localUser.Status = bookpackage.Status;
                    Context.Add<BookPackage>(localUser);
                    Context.SaveChanges();
                    status = 1;
                }
                else
                {
                    status = 0;
                }

            }
            catch (Exception)
            {
                status = 0;
            }
            return status;
        }
        #endregion

        #region Customer Care
        public int AddCustomerQuery(CustomerCare cc)
        {
            int status = 0;
            CustomerCare localUser = new CustomerCare();
            //Hotel temp = new Hotel();
            try
            {
                localUser.BookingId = cc.BookingId;
                localUser.Query = cc.Query;
                localUser.QueryStatus = cc.QueryStatus;


                Context.Add<CustomerCare>(localUser);
                Context.SaveChanges();
                status = 1;
            }
            catch (Exception)
            {
                status = 0;
            }
            return status;
        }
        #endregion

        #region Add Accomodation
        public int AddAccomodation(Accomodation acc)
        {
            int status = 0;
            Accomodation localUser = new Accomodation();
            //Hotel temp = new Hotel();
            try
            {

                localUser.BookingId = acc.BookingId;
                localUser.AccomodationId = acc.AccomodationId;
                localUser.HotelName = acc.HotelName;
                localUser.City = acc.City;
                localUser.NoOfRooms = acc.NoOfRooms;
                localUser.HotelRating = acc.HotelRating;
                localUser.Price = acc.Price;
                localUser.RoomType = acc.RoomType;
                Context.Add<Accomodation>(localUser);
                Context.SaveChanges();
                status = 1;
            }
            catch (Exception)
            {
                status = 0;
            }
            return status;
        }
        #endregion


    }
}

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using Infosys.TravelAway.DAL.Models;
//using Microsoft.Data.SqlClient;
//using Microsoft.EntityFrameworkCore;

//namespace Infosys.TravelAway.DAL
//{
//    public class TravelAwayRepository
//    {
//        TravelAwayDBContext context;

//        public TravelAwayRepository()
//        {
//            context = new TravelAwayDBContext();
//        }
//        //public bool AddCustomer(params Customer[] custDetails)
//        //{
//        //    bool status = false;
//        //    try
//        //    {
//        //        //context.Customer.Add(customer);
//        //        context.Customer.AddRange(custDetails);
//        //        context.SaveChanges();
//        //        status = true;
//        //    }
//        //    catch (Exception)
//        //    {
//        //        status = false;
//        //    }
//        //    return status;
//        //}


//        //public string CustLogin(string emailId, string password)
//        //{
//        //    string roleName = "";
//        //    try
//        //    {
//        //        var objUser = (from usr in context.Customer
//        //                       where usr.EmailId == emailId && usr.UserPassword == password
//        //                       select usr.Role).FirstOrDefault<Roles>();
//        //        if (objUser != null)
//        //        {
//        //            roleName = objUser.RoleName;
//        //        }
//        //        else
//        //        {
//        //            roleName = "Invalid credentials";
//        //        }
//        //    }
//        //    catch (Exception)
//        //    {
//        //        roleName = "Invalid credentials";
//        //    }
//        //    return roleName;
//        //}
//        //public string EmpLogin(string emailId, string password)
//        //{
//        //    string roleName = "";
//        //    try
//        //    {
//        //        var objUser = (from usr in context.Customer
//        //                       where usr.EmailId == emailId && usr.UserPassword == password
//        //                       select usr.Role).FirstOrDefault<Roles>();
//        //        if (objUser != null)
//        //        {
//        //            roleName = objUser.RoleName;
//        //        }
//        //        else
//        //        {
//        //            roleName = "Invalid credentials";
//        //        }
//        //    }
//        //    catch (Exception)
//        //    {
//        //        roleName = "Invalid credentials";
//        //    }
//        //    return roleName;
//        //}

//        //public List<PackageCategory> GetAllPackages()
//        //{
//        //    var categoriesList = (from category in context.PackageCategory
//        //                          orderby category.PackageCategoryId
//        //                          select category).ToList();
//        //    return categoriesList;
//        //}

//public bool AddCustomer(Customer customer)
//{
//    bool status = false;
//    Customer localUser = new Customer();
//    Customer temp = new Customer();
//    try
//    {
//        temp = context.Customer.Where(P => P.EmailId == customer.EmailId).Select(p => p).FirstOrDefault();
//        if (temp == null)
//        {
//            localUser.FirstName = customer.FirstName;
//            localUser.LastName = customer.LastName;
//            localUser.EmailId = customer.EmailId;
//            localUser.UserPassword = customer.UserPassword;
//            localUser.Gender = customer.Gender;
//            localUser.ContactNumber = customer.ContactNumber;
//            localUser.DateOfBirth = customer.DateOfBirth;
//            localUser.Address = customer.Address;
//            context.Add<Customer>(localUser);
//            context.SaveChanges();
//            status = true;
//        }
//        else
//        {
//            status = false;
//        }
//        //context.Customer.Add(customer);

//    }
//    catch (Exception)
//    {
//        status = false;
//    }
//    return status;
//}
//        public bool CustLogin(string emailId, string password)
//        {
//            bool status = false;
//            try
//            {
//                var objUser = (from usr in context.Customer
//                               where usr.EmailId == emailId && usr.UserPassword == password
//                               select usr).FirstOrDefault();
//                if (objUser != null)
//                {
//                    status = true;
//                }
//                else
//                {
//                    status = false;
//                }
//            }
//            catch (Exception)
//            {
//                status = false;
//            }
//            Console.WriteLine(status);
//            return status;
//        }
//        public bool EditProfile(string emailId,string firstname,string lastname,decimal contactnumber,string gender,string address)
//        {
//            bool status = false;
//            var record = context.Customer.Find(emailId);
//            try
//            {
//                if (record != null)
//                {
//                    record.FirstName = firstname;
//                    record.LastName = lastname;
//                    record.ContactNumber = contactnumber;
//                    record.Address = address;

//                    context.SaveChanges();
//                    status = true;
//                }
//            }
//            catch (Exception)
//            {
//                status = false;
//            }
//            return status;
//        }

//    }
//}

//public int RegisterNewCustomer(Customer newCust)
//{
//    int result;
//    try
//    {
//        SqlParameter prmFirstName = new SqlParameter("@firstName", newCust.FirstName);
//        SqlParameter prmLastName = new SqlParameter("@lastName", newCust.LastName);
//        SqlParameter prmPassword = new SqlParameter("@userPassword", newCust.UserPassword);
//        SqlParameter prmGender = new SqlParameter("@gender", newCust.Gender);
//        SqlParameter prmEmailId = new SqlParameter("@emailId", newCust.EmailId);
//        SqlParameter prmDob = new SqlParameter("@dateOfBirth", newCust.DateOfBirth);
//        SqlParameter prmNumber = new SqlParameter("@contactNumber", newCust.ContactNumber);
//        SqlParameter prmAddress = new SqlParameter("@address", newCust.Address);

//        SqlParameter prmReturnResult = new SqlParameter("@ReturnResult", System.Data.SqlDbType.Int);
//        prmReturnResult.Direction = System.Data.ParameterDirection.Output;
//        result = Context.Database.ExecuteSqlRaw("EXEC @ReturnResult= usp_RegisterCustomer @emailId,@firstName,@lastName,@userPassword, " +
//            "@gender,@contactNumber,@dateOfBirth,@address",
//            prmReturnResult, prmEmailId, prmFirstName, prmLastName, prmPassword, prmGender, prmNumber, prmDob, prmAddress);
//        if (result > 0)
//        {
//            return result;
//        }

//        else
//        {
//            result = -98;
//            return result;
//        }
//    }
//    catch (Exception )
//    {
//        result = -99;
//        return result;
//    }

//}