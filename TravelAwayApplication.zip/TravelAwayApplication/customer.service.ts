import { Injectable } from '@angular/core';
import { ICustomer } from 'src/app/TravelAway-interfaces/Customer';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  customer: ICustomer[];

  constructor(private http: HttpClient) { }
    ValidateCustomer(id: string, password: string): Observable < string >
    {
     var userObj: ICustomer
     userObj = { EmailId: id, UserPassword: password, Gender: null, RoleId: null, DateOfBirth: null, Address:null, FirstName: null, LastName: null,ContactNumber:null };
     return this.http.post<string>('https://localhost:44347/api/Customer/ValidateCustomer', userObj).pipe(catchError(this.errorHandler));
    }

    InsertUserDetails(emailid:string,firstname:string,lastname:string,userpassword:string,gender:string,contactnumber:number,dateofbirth:Date,address:string): Observable<number> {
      var custObj: ICustomer
      custObj = { EmailId: emailid, RoleId: null, FirstName: firstname, LastName: lastname, UserPassword: userpassword, Gender: gender, DateOfBirth: dateofbirth, ContactNumber: contactnumber, Address: address };
      let temp = this.http.post<number>('https://localhost:44347/api/Customer/InsertUserDetails', custObj).pipe(catchError(this.errorHandler));
      return temp;
    }

    errorHandler(error: HttpErrorResponse) {
      console.error(error);
      return throwError(error.message || "Server Error");
    }
  }


