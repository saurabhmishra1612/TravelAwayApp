﻿using System;
using Infosys.TravelAway.DAL;
using Infosys.TravelAway.DAL.Models;

namespace Infosys.TravelAway.ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            TravelAwayRepository repository = new TravelAwayRepository();
            //Customer CustOne = new Customer();
            //CustOne.EmailId = "Sanil.jain@gmail.com";
            //CustOne.RoleId = 1;
            //CustOne.FirstName = "Sanil";
            //CustOne.LastName = "Jain";
            //CustOne.UserPassword = "Sai@12345";
            //CustOne.Gender = "M";
            //CustOne.ContactNumber = 9424322130;
            //CustOne.DateOfBirth = DateTime.FromOADate(01 / 01 / 1998);
            //CustOne.Address = "Jabalpurpur";

            ////int result = repository.AddCustomer(CustOne);
            //int result = repository.GetPackageDetailsByPackageId(CustOne);
            ////            int result = repository.ValidateLoginCustomer("jain.sakshi@gmail.com", "SAKSHI@1234");
            ////bool result = repository.EditProfile("Art@gmail.com", "ssaai", "ppp",7894561232,"F", "srtejdd");
            ////int result = repository.GetPackagesByCategoryId(100);
            //if (result==1)
            //{
            //    Console.WriteLine("Customer Details added successfully!");
            //    //{
            //    //    Console.WriteLine("{0}\t\t{1}", category.PackageCategoryId, category.PackageCategoryName);
            //    //}
            //}
            //else
            //{
            //    Console.WriteLine("Some error occurred. Try again!!");
            //}
            var categories = repository.GetPackageDetailsByPackageId(2001);
            foreach (var category in categories)
            {
                Console.WriteLine("{0}\t\t{1}", category.PlcesToVisit, category.Description);
            }
        }

    }
}
