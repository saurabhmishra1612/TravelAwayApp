import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { PackageService } from '../TravelAwayServices/Package-Service/package.service';
import { ICustomerCare } from '../TravelAway-interfaces/CustomerCare';

@Component({
  selector: 'app-customer-care',
  templateUrl: './customer-care.component.html',
  styleUrls: ['./customer-care.component.css']
})
export class CustomerCareComponent implements OnInit {
  cc: ICustomerCare[];
  customercareForm: FormGroup;
  msg: string;
  showDiv: boolean;
  errorMsg: string;
  status: number;
  constructor(private _PackageService: PackageService, private formBuilder: FormBuilder) {
    this.customercareForm = this.formBuilder.group({
      bookingid: [''],
      query: ['']
    });
  }
  ngOnInit() {
  }
  SubmithForm(form: FormGroup) {
    var booking = form.value.bookingid;
    this._PackageService.addcustomercareDetails(form.value.bookingid, form.value.query,"Assigned").subscribe(
        responseRegisterStatus => {
          this.status = responseRegisterStatus;
          this.showDiv = true;
          if (this.status == 1) {
            this.msg = "Added Successfully";
            sessionStorage.setItem('userName', booking);
            //this.router.navigate(['/home']);
          } else {
            this.msg = "Not able to add";
          }
        },
        responseRegisterError => {
          this.errorMsg = responseRegisterError;
        },
        () => console.log("Form executed successfully")
      );
  }
}
