import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { PackageService } from '../TravelAwayServices/Package-Service/package.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-book-package',
  templateUrl: './book-package.component.html',
  styleUrls: ['./book-package.component.css']
})
export class BookPackageComponent implements OnInit {
  bookpackageForm: FormGroup;
  msg: string;
  showDiv: boolean;
  errorMsg: string;
  status: number;
  packageId: string;

  constructor(private packageService: PackageService, private formBuilder: FormBuilder, private route: ActivatedRoute) {
    this.bookpackageForm = this.formBuilder.group({
      emailid: [''],
      contactnumber: [''],
      address: [''],
      dateoftravel: [''],
      numberofadults: [''],
      numberofchildren: ['']
    });
  }
  ngOnInit() {
    this.packageId = this.route.snapshot.params['packageId'];
    //this.SubmitForm(FormGroup);
  }
  SubmitForm(form: FormGroup) {
    var email = form.value.emailid;
    this.packageService.bookpackageDetails(form.value.emailid, parseInt(form.value.contactnumber),
      form.value.address, form.value.dateoftravel, form.value.numberofadults, form.value.numberofchildren, "Approved").subscribe(
        responseRegisterStatus => {
          this.status = responseRegisterStatus;
          this.showDiv = true;
          if (this.status == 1) {
            this.msg = "Registered Successfully";
            sessionStorage.setItem('userName', email);
            //sessionStorage.setItem('userRole', "Customer");
            //this.router.navigate(['/home']);
          } else {
            this.msg = "Not able to register";
          }
        },
        responseRegisterError => {
          this.errorMsg = responseRegisterError;
        },
        () => console.log("SubmitForm method executed successfully")
      );
  }
}
