import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from '../TravelAwayservices/Customer-Service/customer.service';

@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateProfileComponent implements OnInit {
  updateprofileForm: FormGroup;
  msg: string;
  showDiv: boolean;
  errorMsg: string;
  status: number;

  constructor(private customerservice: CustomerService, private formBuilder: FormBuilder) {
    this.updateprofileForm = this.formBuilder.group({
      firstname: [''],
      lastname: [''],
      emailid: [''],
      gender: [''],
      dateofbirth: [''],
      contactnumber: [''],
      address: ['']
    });
  }



  ngOnInit(): void {
  }

  SubmitForm(form: FormGroup) {
    var email = form.value.emailid;
    this.customerservice.updateprofileDetails(form.value.firstname, form.value.lastname, form.value.emailid,
      parseInt(form.value.contactnumber), form.value.address, form.value.gender, new Date("1999-08-23")).subscribe(
        responseRegisterStatus => {
          this.status = responseRegisterStatus;
          this.showDiv = true;
          if (this.status == 1) {
            this.msg = "Registered Successfully";
            sessionStorage.setItem('userName', email);
            //sessionStorage.setItem('userRole', "Customer");
            //this.router.navigate(['/home']);
          } else {
            this.msg = "Not able to register";
          }
        },
        responseRegisterError => {
          this.errorMsg = responseRegisterError;
        },
        () => console.log("SubmitForm method executed successfully")
      );
  }
}
