import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { CustomerService } from '../../TravelAwayservices/Customer-Service/customer.service';

@Component({
  selector: 'app-employee-login',
  templateUrl: './employee-login.component.html',
  styleUrls: ['./employee-login.component.css']
})
export class EmployeeLoginComponent implements OnInit {

  status: number;
  credStatus: string;
  errorMsg: string;
  msg: string;
  showDiv: boolean = false;
  name: string;
  loginRole: 2
  rolename: string;
  constructor(private customerService: CustomerService, private router: Router, private route: ActivatedRoute) {
    //this.loginRole = parseInt(this.route.snapshot.params['loginRole']);
    if (this.loginRole == 2) this.rolename = "Employee";
    else if (this.loginRole == 1) this.rolename = "Customer";
  }

  ngOnInit(): void {

  }
  submitLoginForm(form: NgForm) {
    console.log(form.value.email, form.value.password);
    this.customerService.validateEmployeeCredentials(form.value.email, form.value.password).subscribe(
      responseLoginStatus => {
        this.status = responseLoginStatus;
        this.showDiv = true;
        if (this.status == 1) {
          this.msg = "Login Successful";
          console.log(this.msg);
          sessionStorage.setItem('userName', form.value.email);
          sessionStorage.setItem('userRole', "Customer");
          this.router.navigate(['/home']);
        }
        else if (this.status == 2) {
          this.msg = "Login Successful";
          sessionStorage.setItem('userName', form.value.email);
          sessionStorage.setItem('userRole', "Employee");
          this.router.navigate(['/home']);
        }
        else {
          this.msg = "Try again with valid credentials.";
          console.log(this.msg);
        }
      },
      responseLoginError => {
        this.errorMsg = responseLoginError;
      },
      () => console.log("SubmitLoginForm method executed successfully")
    );
  }
}
