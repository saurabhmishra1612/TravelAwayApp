import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { CustomerService } from '../../TravelAwayservices/Customer-Service/customer.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  status: number;
  credStatus: string;
  errorMsg: string;
  msg: string;
  showDiv: boolean = false;
  name: string;
  loginRole: 1
  rolename: string;
  constructor(private customerService: CustomerService, private router: Router, private route: ActivatedRoute) {
    //this.loginRole = parseInt(this.route.snapshot.params['loginRole']);
    if (this.loginRole == 1) this.rolename = "Customer";
    else if (this.loginRole == 2) this.rolename = "Employee";
  }

  ngOnInit(): void {

  }
  submitLoginForm(form: NgForm) {
  console.log(form.value.email, form.value.password);
  this.customerService.validateCredentials(form.value.email, form.value.password).subscribe(
    responseLoginStatus => {
      this.status = responseLoginStatus;
      this.showDiv = true;
      if (this.status == 1) {
        this.msg = "Login Successful";
        console.log(this.msg);
        sessionStorage.setItem('userName', form.value.email);
        sessionStorage.setItem('userRole', "Customer");
        this.router.navigate(['/home']);
      }
      else if (this.status == 2 && this.credStatus.toLowerCase() != "invalid credentials") {
        this.msg = "Login Successful";
        sessionStorage.setItem('userName', form.value.email);
        sessionStorage.setItem('userRole', "Employee");
        this.router.navigate(['/home']);
        console.log(this.msg);
      }
      else {
        this.msg = "Try again with valid credentials.";
        console.log(this.msg);
      }
    },
    responseLoginError => {
      this.errorMsg = responseLoginError;
    },
    () => console.log("SubmitLoginForm method executed successfully")
  );
}
}


//import { Component, OnInit } from '@angular/core';
//import { NgForm, FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
//import { CustomerService } from '../TravelAwayservices/Customer-Service/customer.service';
//@Component({
////  selector: 'app-login',
////  templateUrl: './login.component.html',
////  styleUrls: ['./login.component.css']
////})
////export class LoginComponent implements OnInit {
////  status: string;
////  errorMsg: string;
////  msg: string;
////  showDiv: boolean = false;
////  name: string;
////  loginRole: number;

//  constructor(private _customerService: CustomerService) { }
//  submitLoginForm(form: NgForm) {
//    this._customerService.ValidateCustomer(form.value.email, form.value.password).subscribe(
//      responseLoginStatus => {
//        this.status = responseLoginStatus;
//        this.showDiv = true;
//        if (this.status.toLowerCase() != "invalid credentials") {
//          console.log(status);
//          sessionStorage.setItem('userName', form.value.email);
//          //sessionStorage.setItem('userRole', this.status);
//        }
//        else {
//          this.msg = this.status + ". Try again with valid credentials.";
//        }
//      },
//      responseLoginError => {
//        this.errorMsg = responseLoginError;
//      },
//      () => console.log("SubmitLoginForm method executed successfully")
//    );
//  }


//  ngOnInit(): void {
//  }

//}
