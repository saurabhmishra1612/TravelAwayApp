import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { PackageService } from '../TravelAwayServices/Package-Service/package.service';

@Component({
  selector: 'app-hotel',
  templateUrl: './hotel.component.html',
  styleUrls: ['./hotel.component.css']
})
export class HotelComponent implements OnInit {
  hotelForm: FormGroup;
  msg: string;
  showDiv: boolean;
  errorMsg: string;
  status: number;
  constructor(private packageService: PackageService, private formBuilder: FormBuilder) {
    this.hotelForm = this.formBuilder.group({
      hotelname: ['', Validators.required],
      hotelrating: ['', Validators.required],
      singleroomprice: ['', Validators.required],
      doubleroomprice: [''],
      deluxeeroomprice: [''],
      suiteroomprice: [''],
      city: ['', Validators.required],
      packageid: ['']
    });
  }
  ngOnInit(): void {
  }
  SubmitForm(form: FormGroup) {
    var hotelname = form.value.hotelname;
    this.packageService.addHotelDetails(form.value.hotelname, form.value.hotelrating, form.value.singleroomprice,
      form.value.doubleroomprice, parseInt(form.value.deluxeeroomprice), form.value.suiteroomprice, form.value.city, form.value.packageid).subscribe(
        responseRegisterStatus => {
          this.status = responseRegisterStatus;
          this.showDiv = true;
          if (this.status == 1) {
            this.msg = "Added Successfully";
            sessionStorage.setItem('userName', hotelname);
            //this.router.navigate(['/home']);
          } else {
            this.msg = "Not able to add";
          }
        },
        responseRegisterError => {
          this.errorMsg = responseRegisterError;
        },
        () => console.log("Form executed successfully")
      );
  }
}
