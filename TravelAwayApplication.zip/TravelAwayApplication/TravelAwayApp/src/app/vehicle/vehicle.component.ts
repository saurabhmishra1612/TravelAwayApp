import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { VehicleService } from '../TravelAwayservices/Vehicle-Service/vehicle.service';
import { IVehicle } from '../TravelAway-interfaces/Vehicle';

@Component({
  selector: 'app-vehicle',
  templateUrl: './vehicle.component.html',
  styleUrls: ['./vehicle.component.css']
})
export class VehicleComponent implements OnInit {
  veh: IVehicle[];
  vehicleForm: FormGroup;
  msg: string;
  showDiv: boolean;
  errorMsg: string;
  status: number;

  constructor(private vehicleservice: VehicleService, private formBuilder: FormBuilder) { 
    this.vehicleForm = this.formBuilder.group({
      vehiclename: [''],
      vehicletype: [''],
      rateperhour: [''],
      rateperkm: [''],
      baseprice: ['']
    });
  }

  ngOnInit() {
  }
  SubmitvForm(form: FormGroup) {
    var vehiclen = form.value.vehiclename;
    this.vehicleservice.addVehicleDetails(form.value.vehiclename, form.value.vehicletype, form.value.rateperhour,
      form.value.rateperkm, form.value.baseprice).subscribe(
        responseRegisterStatus => {
          this.status = responseRegisterStatus;
          this.showDiv = true;
          if (this.status == 1) {
            this.msg = "Added Successfully";
            sessionStorage.setItem('userName', vehiclen);
            //this.router.navigate(['/home']);
          } else {
            this.msg = "Not able to add";
          }
        },
        responseRegisterError => {
          this.errorMsg = responseRegisterError;
        },
        () => console.log("Form executed successfully")
      );
  }
}



