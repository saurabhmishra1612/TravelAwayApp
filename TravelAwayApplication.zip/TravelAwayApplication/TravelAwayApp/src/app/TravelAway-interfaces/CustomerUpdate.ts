export interface ICustomerUpdate {
  EmailId: string
  FirstName: string
  LastName: string
  Gender: string
  ContactNumber: number
  DateOfBirth: Date
  Address: string
}
