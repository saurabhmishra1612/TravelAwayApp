export interface ICustomerCare {
  BookingId: number
  Query: string
  QueryStatus: string
}
