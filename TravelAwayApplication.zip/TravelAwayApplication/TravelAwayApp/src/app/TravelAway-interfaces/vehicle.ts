export interface IVehicle {
  //HotelId: number
  VehicleName: string
  VehicleType: string
  RatePerHour: number
  RatePerKM: number
  BasePrice:number
}


