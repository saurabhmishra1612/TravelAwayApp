export interface IBookPackage {
  EmailId: string
  //BookingId: number
  //PackageId: number
  ContactNumber: number
  Address: string
  DateOfTravel: Date
  NumberOfAdults: number
  NumberOfChildren: number
  Status: string
}
