export interface ICategory {
  PackageCategoryId: number
  PackageCategoryName:string
}
