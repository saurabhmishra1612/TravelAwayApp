import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { IPackage } from 'src/app/travelAway-interfaces/Package';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ICategory } from 'src/app/TravelAway-interfaces/Category'
import { IPackageDetails } from 'src/app/TravelAway-interfaces/PackageDetails';
import { IHotel } from 'src/app/TravelAway-interfaces/Hotel';
import { IVehicle } from 'src/app/TravelAway-interfaces/Vehicle';
import { IAccomodation } from 'src/app/TravelAway-interfaces/Accomodation';
import { IBookPackage } from '../../TravelAway-interfaces/BookPackage';
import { ICustomerCare } from '../../TravelAway-interfaces/CustomerCare';

@Injectable({
  providedIn: 'root'
})
export class PackageService {

  constructor(private http: HttpClient) { }

  getPackages(): Observable<IPackage[]> {
    let temp = this.http.get<IPackage[]>('https://localhost:44347/api/Customer/GetPackages').pipe(catchError(this.errorHandler))
    return temp;
  }

  getCategories(): Observable<ICategory[]> {
    return this.http.get<ICategory[]>('https://localhost:44347/api/Customer/GetPackageCategories').pipe(catchError(this.errorHandler));
  }

  getPackageDetails(packageId: string): Observable<IPackageDetails[]> {
    let param = "?packageId=" + packageId;
    let address = 'https://localhost:44347/api/Customer/GetPackageDetailsByPackageId' + param;
    console.log(address)
    return this.http.get<IPackageDetails[]>(address).pipe(catchError(this.errorHandler));
  }

  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error");
  }

  addHotelDetails(hotelname: string, hotelrating: number, singleroomprice: number, doubleroomprice: number, deluxeeroomprice: number, suiteroomprice: number, city: string, packageid: number): Observable<number> {
    var hObj: IHotel
    hObj = {
      HotelName: hotelname, HotelRating: hotelrating, SingleRoomPrice: singleroomprice, DoubleRoomPrice: doubleroomprice, DeluxeeRoomPrice: deluxeeroomprice,
      SuiteRoomPrice: suiteroomprice, City: city, PackageId: packageid
    };
    let temp = this.http.post<number>('https://localhost:44347/api/Customer/AddNewHotel', hObj).pipe(catchError(this.errorHandler));
    return temp;
  }


  addVehicleDetails(vehiclename: string, vehicletype: string, rateperhour: number, rateperkm: number, baseprice: number): Observable<number> {
    var vObj: IVehicle
    vObj = {
      VehicleName: vehiclename, VehicleType: vehicletype, RatePerHour: rateperhour, RatePerKM: rateperkm, BasePrice: baseprice
    };
    let temp = this.http.post<number>('https://localhost:44347/api/Customer/AddVehicle', vObj).pipe(catchError(this.errorHandler));
    return temp;
  }

  addAccomodationDetails(hotelname: string, city: string, noofrooms: number, hotelrating: number, price: number, roomtype: string): Observable<number> {
    var aObj: IAccomodation
    aObj = {
      HotelName: hotelname, City: city, NoOfRooms: noofrooms, HotelRating: hotelrating, Price: price, RoomType: roomtype
    };
    let temp = this.http.post<number>('https://localhost:44347/api/Customer/AddAccomodation', aObj).pipe(catchError(this.errorHandler));
    return temp;
  }

  bookpackageDetails(emailid: string, contactnumber: number, address: string, dateoftravel: Date, numberofadults: number, numberofchildren: number, status: string): Observable<number> {
    var bObj: IBookPackage
    bObj = {
      EmailId: emailid, ContactNumber: contactnumber, Address: address, DateOfTravel: dateoftravel, NumberOfAdults: numberofadults,
      NumberOfChildren: numberofchildren, Status: status
    };
    let temp = this.http.post<number>('https://localhost:44347/api/Customer/BookPackage', bObj).pipe(catchError(this.errorHandler));
    return temp;
  }

  addcustomercareDetails(bookingid: number, query: string, querystatus): Observable<number> {
    var cObj: ICustomerCare
    cObj = {
      BookingId: bookingid, Query: query, QueryStatus: querystatus
    };
    let temp = this.http.post<number>('https://localhost:44347/api/Customer/AddCustomerQuery', cObj).pipe(catchError(this.errorHandler));
    return temp;
  }
}
