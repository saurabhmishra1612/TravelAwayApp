//import { Component, OnInit } from '@angular/core';
//import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
//import { NgForm } from '@angular/forms';
//import { Router } from '@angular/router';
//import { CustomerService } from '../TravelAwayservices/Customer-Service/customer.service';
//import { PackageService } from '../TravelAwayServices/Package-Service/package.service';

//@Component({
//  selector: 'app-book-accomodation',
//  templateUrl: './book-accomodation.component.html',
//  styleUrls: ['./book-accomodation.component.css']
//})
//export class BookAccomodationComponent implements OnInit {
//  accomodationForm: FormGroup;
//  msg: string;
//  showDiv: boolean;
//  errorMsg: string;
//  status: number;
//  constructor(private packageservice: PackageService, private formBuilder: FormBuilder) {
//    this.accomodationForm = this.formBuilder.group({
//      hotelname: [''],
//      city: [''],
//      noofrooms: [''],
//      hotelrating: [''],
//      price: [''],
//      roomtype: [''],

//    });
//  }
//  ngOnInit(): void {
//  }
//  SubmitAccForm(form: NgForm) {
//    var email = form.value.hotelname;
//    this.packageservice.addAccomodationDetails(form.value.hotelname, form.value.city, form.value.noofrooms,
//      form.value.hotelrating, form.value.price, form.value.roomtype).subscribe(
//        responseRegisterStatus => {
//          this.status = responseRegisterStatus;
//          this.showDiv = true;
//          if (this.status == 1) {
//            this.msg = "Added Successfully";
//            sessionStorage.setItem('userName', email);
//            //sessionStorage.setItem('userRole', "Customer");
//            //this.router.navigate(['/home']);
//          } else {
//            this.msg = "Not able to register";
//          }
//        },
//        responseRegisterError => {
//          this.errorMsg = responseRegisterError;
//        },
//        () => console.log("SubmitForm method executed successfully")
//      );
//  }
//}

